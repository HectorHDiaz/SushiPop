﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SushiPOP_BE1B_2C2023_G1.Migrations
{
    public partial class init3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

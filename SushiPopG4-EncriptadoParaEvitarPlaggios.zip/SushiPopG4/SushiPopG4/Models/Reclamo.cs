﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    [Table("T_RECLAMO")]
    public class Reclamo
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Nombre completo")]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [MaxLength(255, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        public string NombreCompleto { get; set; }

        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [MaxLength(1000, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        public string Email { get; set; }

        [Display(Name = "Teléfono")]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [StringLength(10, ErrorMessage = ErrorViewModel.CaracteresTelefono, MinimumLength = 10)]
        public string Telefono { get; set; }

        [Display(Name = "Detalle")]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [StringLength(4000, ErrorMessage = ErrorViewModel.CantidadCaracteres, MinimumLength = 50)]
        public string DetalleReclamo { get; set; }

        public int PedidoId { get; set; }

        [Display(Name = "Número de pedido")]
        [ForeignKey("PedidoId")]
        public Pedido? Pedido { get; set; }

    }
}

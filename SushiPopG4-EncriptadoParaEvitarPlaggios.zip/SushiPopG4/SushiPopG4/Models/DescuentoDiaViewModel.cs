﻿namespace SushiPopG4.Models
{
    public class DescuentoDiaViewModel
    {
        public int? Descuento { get;set; }
        public string? Dia { get; set; }
        public string? Producto { get; set ;}

        public int? ProductoId { get; set; }    

        public string HorarioAtencion { get; set; }
    }
}

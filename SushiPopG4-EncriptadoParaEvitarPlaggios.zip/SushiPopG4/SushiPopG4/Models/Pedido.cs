﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    [Table("T_PEDIDO")]
    public class Pedido
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Número de pedido")]
        public int? NroPedido { get; set; }

        [Display(Name = "Fecha y hora del pedido")]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime? FechaCompra { get; set; }

        [DataType("DECIMAL(19.4)")]
        public decimal? Subtotal { get; set; }

        [Display(Name = "Gasto de envío")]
        [DataType("DECIMAL(19.4)")]
        public decimal? GastoEnvio { get; set; }

        [DataType("DECIMAL(19.4)")]
        public decimal? Total { get; set; }
        public int? Estado { get; set; }

        public virtual Reclamo? Reclamo { get; set; }
        public int CarritoId { get; set; }

        [ForeignKey("CarritoId")]
        public Carrito? Carrito { get; set; }


    }
}

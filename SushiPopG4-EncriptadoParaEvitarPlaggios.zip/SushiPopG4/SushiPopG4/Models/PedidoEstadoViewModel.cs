﻿namespace SushiPopG4.Models
{
    public class PedidoEstadoViewModel
    {
        public int? NumeroPedido { get; set;}
    }
}

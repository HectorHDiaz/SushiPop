﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    [Table("T_CLIENTE")]
    public class Cliente : Usuario
    {
        [Display(Name = "Número de cliente")]
        public int? NumeroCliente { get; set; }

        public List<Carrito>? Carritos { get; set; }
        public List<Reserva>? Reservas { get; set; }

    }
}

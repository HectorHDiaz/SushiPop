namespace SushiPopG4.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        public const string CampoRequerido = "el campo {0} es obligatorio";
        public const string CantidadCaracteres = "{0} debe tener entre {2} y {1} caracteres";
        public const string MaxCaracteres = "{1} es la cantidad m�xima de caracteres permitidos";
        public const string CaracteresTelefono = "{0} requiere {1} caracteres";
    }
}
﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    [Table("T_CATEGORIA")]
    public class Categoria
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(100, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        public string Nombre { get; set; }

        [DisplayName("Descripción")]
        [MaxLength(4000, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        public string? Descripcion { get; set;}

        public List<Producto>? Productos { get; set; }
    }
}

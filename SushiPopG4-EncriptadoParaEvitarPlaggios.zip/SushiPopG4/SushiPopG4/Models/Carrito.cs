﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    [Table("T_CARRITO")]
    public class Carrito
    {
        [Key]
        public int Id { get; set; }
        public bool? Procesado { get; set; }
        public bool? Cancelado { get; set; }

        public int? ClienteId { get; set; }
        [ForeignKey("ClienteId")]
        public Cliente? Cliente { get; set; }
        public virtual Pedido? Pedido { get; set; }
        public List<CarritoItem>? CarritosItems { get; set; }

    }
}

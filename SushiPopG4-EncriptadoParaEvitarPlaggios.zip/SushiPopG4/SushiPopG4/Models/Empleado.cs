﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    [Table("T_EMPLEADO")]
    public class Empleado : Usuario
    {
        [Display(Name = "Número de legajo")]
        public int? Legajo { get; set; }
    }
}

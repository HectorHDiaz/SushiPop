﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    [Table("T_RESERVA")]
    public class Reserva
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [MaxLength(50, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        public string Local { get; set;}

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy HH:mm}", ApplyFormatInEditMode = true)]
        [DisplayName("Fecha y hora")]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        public DateTime FechaHora { get; set; }
        public bool? Confirmada { get; set; }

        public int ClienteId { get; set; }

        [ForeignKey("ClienteId")]
        public Cliente? Cliente { get; set; }



    }
}

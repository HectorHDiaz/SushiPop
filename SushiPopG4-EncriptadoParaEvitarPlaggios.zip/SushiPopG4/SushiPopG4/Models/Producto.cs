﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    [Table("T_PRODUCTO")]
    public class Producto
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(100, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        public string Nombre { get; set; }

        [StringLength(250, ErrorMessage = ErrorViewModel.CantidadCaracteres, MinimumLength = 20)]
        [DisplayName("Descripción")]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        public string Descripcion { get; set; }

        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [Range(1, double.PositiveInfinity)]
        [DataType("DECIMAL(19.4)")]
        public decimal Precio { get; set; }

        [Display(Name = "URL Fotografía")]
        [MaxLength(1000, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        public string? Foto { get; set; }

        [Range(1, double.PositiveInfinity)]
        public int Stock { get; set; }

        public int CategoriaId { get; set; }

        [ForeignKey("CategoriaId")]
        public Categoria? Categoria { get; set; }
        public List<Descuento>? Descuentos { get; set; }
        public List<CarritoItem>? CarritoItems { get; set; }


    }
}

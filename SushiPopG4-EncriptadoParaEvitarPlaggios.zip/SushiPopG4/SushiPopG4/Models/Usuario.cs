﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    public abstract class Usuario
    {
        [Key]
        public int Id { get; set; }

        [StringLength(30, ErrorMessage = ErrorViewModel.CantidadCaracteres, MinimumLength = 5)]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        public string Nombre { get; set; }

        [StringLength(30, ErrorMessage = ErrorViewModel.CantidadCaracteres, MinimumLength = 5)]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        public string Apellido { get; set; }

        [MaxLength(100, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [DisplayName("Dirección")]
        public string Direccion { get; set; }

        [StringLength(10, ErrorMessage = ErrorViewModel.CaracteresTelefono)]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [DisplayName("Teléfono Celular")]
        public string Telefono { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [DisplayName("Fecha de Nacimiento")]
        public DateTime FechaNacimiento { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy HH:mm}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha de alta")]
        public DateTime? FechaAlta { get; set; }
        public bool? Activo { get; set; }

        public string? Email { get; set; }
    }
            
            
}

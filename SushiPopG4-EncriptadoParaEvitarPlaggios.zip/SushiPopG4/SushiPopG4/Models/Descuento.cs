﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    [Table("T_DESCUENTO")]
    public class Descuento
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Día")]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [Range(1, 7)]
        public int Dia { get; set; }

        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [Range(1, 100)]
        public int Porcentaje { get; set; }

        [Display(Name = "Descuento máximo")]
        [Range(1, double.PositiveInfinity)]
        [DataType("DECIMAL(19.4)")]
        public decimal? DescuentoMax { get; set; }
        public bool? Activo { get; set; }
        
        public int? ProductoId { get; set; }
        [ForeignKey("ProductoId")]
        public Producto? Producto { get; set; }
    }
}

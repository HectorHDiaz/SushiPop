﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SushiPopG4.Models
{
    [Table("T_CONTACTO")]
    public class Contacto
    {
        [Key]
        public int ID { get; set; }

        [DisplayName("Nombre completo")]
        [MaxLength(255, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        public string NombreCompleto { get; set; }
        
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [MaxLength(100, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        public string Email { get; set; }

        [DisplayName("Teléfono")]
        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [StringLength(10, ErrorMessage = ErrorViewModel.CaracteresTelefono, MinimumLength = 10)]
        public string Telefono { get; set; }

        [Required(ErrorMessage = ErrorViewModel.CampoRequerido)]
        [MaxLength(4000, ErrorMessage = ErrorViewModel.MaxCaracteres)]
        public string Mensaje { get; set; }

        [Display(Name = "Leído")]
        public bool? Leido { get; set; }
    }
}

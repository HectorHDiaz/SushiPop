﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using AspNetCoreHero.ToastNotification.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SushiPopG4.Models;

namespace SushiPopG4.Controllers
{
    public class PedidosController : Controller
    {
        private readonly DbContext _context;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly INotyfService _notfy;

        public PedidosController(DbContext context, UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager, INotyfService notfy)
        {
            _context = context;
            _userManager = userManager;
            _notfy = notfy;
            _signInManager = signInManager;
        }

        // GET: Pedidos
        [Authorize(Roles = "EMPLEADO, ADMIN, CLIENTE")]
        public async Task<IActionResult> Index()
        {
            var pedido = await _context.Pedido
                    .Include(x => x.Carrito)
                    .Include(x => x.Carrito.Cliente)
                    .Include(x => x.Carrito.CarritosItems)
                    .ThenInclude(x => x.Producto)
                    .ToListAsync();

            if (User.IsInRole("CLIENTE"))
            {
                var user = await _userManager.GetUserAsync(User);
                var pedidosCliente = pedido
                    .Where(x => x.Carrito.Cliente.Email.ToUpper() == user.NormalizedEmail
                            && x.FechaCompra >= DateTime.Now.AddDays(-90))
                    .ToList();

                if(pedidosCliente == null)
                {
                    _notfy.Error("No se encontraron pedidos.", 5);
                    return RedirectToAction("Index", "Home");
                }

                List<PedidoGrillaViewModel> pedidosParaGrilla = new List<PedidoGrillaViewModel>();

                pedidosCliente.ForEach(p =>
                {
                    PedidoGrillaViewModel nuevoItem = new()
                    {
                        Id = p.Id,
                        NroPedido = p.NroPedido,
                        FechaCompra = p.FechaCompra,
                        Subtotal = p.Subtotal,
                        GastoEnvio = p.GastoEnvio,
                        Total = p.Total,
                        Estado = EstadoPedido(p),
                    };
                    pedidosParaGrilla.Add(nuevoItem);
                }
                );

                return View(pedidosParaGrilla);
            }

            var pedidosEmpleado = pedido
                .Where(x => (x.Estado != 5 || x.Estado != 6))
                .ToList();


            if(pedidosEmpleado == null)
            {
                _notfy.Error("No se encontro pedido", 5);
                return RedirectToAction("Index", "Home");

            }

            List<PedidoGrillaViewModel> pedidosParaGrillaEmpleado = new List<PedidoGrillaViewModel>();

            pedidosEmpleado.ForEach(p =>
            {
                PedidoGrillaViewModel nuevoItem = new()
                {
                    Id = p.Id,
                    NroPedido = p.NroPedido,
                    FechaCompra = p.FechaCompra,
                    Subtotal = p.Subtotal,
                    GastoEnvio = p.GastoEnvio,
                    Total = p.Total,
                    Estado = EstadoPedido(p),
                };
                pedidosParaGrillaEmpleado.Add(nuevoItem);
            });

            return View(pedidosParaGrillaEmpleado);

        }

        public async Task<IActionResult> SeguirPedido()
        {
            if (_signInManager.IsSignedIn(User))
            {
                if (User.IsInRole("ADMIN") || User.IsInRole("EMPLEADO"))
                {
                    _notfy.Error("Los administradores y empleados no pueden hacer pedidos.", 5);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    var user = await _userManager.GetUserAsync(User);
                    var pedidoCliente = await _context.Pedido
                        .Include(x => x.Carrito)
                        .ThenInclude(c => c.Cliente)
                        .Where(x => x.Carrito.Cliente.Email.ToUpper() == user.NormalizedEmail)
                        .OrderByDescending(x => x.NroPedido)
                        .FirstOrDefaultAsync();

                    PedidoEstadoViewModel pedidoVm = new PedidoEstadoViewModel()
                    {
                        NumeroPedido = pedidoCliente.NroPedido
                    };
                    return await SeguirPedido(pedidoVm);
                }
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> SeguirPedido([Bind("NroPedido")] PedidoEstadoViewModel pedido)
        {
            var estadoPedido = await _context.Pedido
                .Where(x => x.NroPedido == pedido.NumeroPedido)
                .FirstOrDefaultAsync ();

            if (estadoPedido == null)
            {
                _notfy.Error("No se encontró el número de pedido.", 5);
            }
            return View(pedido);
        }

        public string EstadoPedido(Pedido pedido)
        {
            switch (pedido.Estado)
            {
                case 1: return "Sin Confirmar";
                case 2: return "Confirmado";
                case 3: return "En preparación";
                case 4: return "En reparto";
                case 5: return "Entregado";
                case 6: return "Cancelado";
            }
            return string.Empty;
        }

        [Authorize(Roles = "EMPLEADO")]
        public async Task<IActionResult> Cancelar (int? id)
        {
            if (id == null || _context.Pedido == null)
            {
                _notfy.Error("No se encontro el ID.", 5);
                return RedirectToAction("Index", "Pedidos");
            }

            var pedido = await _context.Pedido.FindAsync(id);
            if(pedido == null)
            {
                _notfy.Error("No se encontro el pedido", 5);
                return RedirectToAction("Index", "Pedidos");
            }

            pedido.Estado = 6;
            _context.Update(pedido);
            await _context.SaveChangesAsync();
            _notfy.Success("Se canceló el pedido", 5);
            return RedirectToAction("Index", "Pedidos");
        }


       
        [Authorize(Roles = "CLIENTE")]
        public async Task<IActionResult> Create()
        {
            var user = await _userManager.GetUserAsync(User);

            var carrito = await _context.Carrito
                .Include(x => x.Cliente)
                .Include(x => x.CarritosItems)
                .ThenInclude(x => x.Producto)
                .Where(x => x.Cliente.Email.ToUpper() == user.NormalizedEmail && (x.Cancelado == false) && (x.Procesado == false))
                .FirstOrDefaultAsync();

            PedidoViewModel pedidoViewModel = new PedidoViewModel()
            {
                CarritoId = carrito.Id,
                Productos = carrito.CarritosItems.ToList(),
                Cliente = carrito.Cliente.Nombre + " " + carrito.Cliente.Apellido,
                Direccion = carrito.Cliente.Direccion,
                Subtotal = (decimal)carrito.CarritosItems.Sum(x => x.PrecioUnitarioConDescuento * x.Cantidad),
                GastoEnvio = 80

            };

            return View(pedidoViewModel);
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CarritoId,Subtotal,GastoEnvio")] PedidoViewModel pedidoVm)
        {
            if (ModelState.IsValid)
            {
                Pedido pedido = new Pedido();
                pedido.CarritoId = pedidoVm.CarritoId;
                pedido.NroPedido = await NroPedido();
                pedido.FechaCompra = DateTime.Now;
                pedido.Subtotal = pedidoVm.Subtotal;
                pedido.GastoEnvio = pedidoVm.GastoEnvio;
                pedido.Total = pedidoVm.Subtotal + pedidoVm.GastoEnvio;
                pedido.Estado = 1;

                _context.Add(pedido);
                await _context.SaveChangesAsync();

                var carrito = await _context.Carrito.FindAsync(pedido.CarritoId);
                carrito.Procesado = true;
                _context.Update(carrito);
                await _context.SaveChangesAsync();

                _notfy.Success("El pedido se creó con éxito", 5);
                return RedirectToAction(nameof(Index));
            }
            
            return View(pedidoVm);
        }

        // GET: Pedidos/Edit/5
        [Authorize(Roles = "EMPLEADO")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Pedido == null)
            {
                return NotFound();
            }

            var pedido = await _context.Pedido.FindAsync(id);
            if (pedido == null)
            {
                return NotFound();
            }
            ViewData["CarritoId"] = new SelectList(_context.Carrito, "Id", "Id", pedido.CarritoId);
            return View(pedido);
        }

        // POST: Pedidos/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "ADMIN, EMPLEADO")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,NroPedido,FechaCompra,Subtotal,GastoEnvio,Total,Estado,CarritoId")] Pedido pedido)
        {
            if (id != pedido.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var pedidoBuscado = await _context.Pedido.FindAsync(pedido.Id);
                    if (pedido.Estado < pedidoBuscado.Estado)
                    {
                        _notfy.Error("No puede cambiarse a un estado anterior", 5);
                        return View(pedido);
                    }

                    _context.Update(pedido);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PedidoExists(pedido.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                _notfy.Success("EL pedido se actualizó con éxito", 5);
                return RedirectToAction(nameof(Index));
            }
            _notfy.Error("El pedido no se pudo actualizar", 5);
            return View(pedido);
        }

        // GET: Pedidos/Delete/5
        [Authorize(Roles = "CLIENTE")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Pedido == null)
            {
                return NotFound();
            }

            var pedido = await _context.Pedido
                .Include(p => p.Carrito)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (pedido == null)
            {
                return NotFound();
            }

            return View(pedido);
        }

        // POST: Pedidos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "CLIENTE")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Pedido == null)
            {
                return Problem("Entity set 'DbContext.Pedido'  is null.");
            }
            var pedido = await _context.Pedido.FindAsync(id);
            if (pedido != null)
            {
                if (pedido.Estado > 1) 
                { 
                    _context.Pedido.Remove(pedido);
                    await _context.SaveChangesAsync();
                    _notfy.Success("Pedido eliminado", 5);
                    
                }
                else
                {
                    _notfy.Error("El pedido no puede eliminarce si ya fue confirmado");
                    
                }
                
            }
            
            return RedirectToAction(nameof(Index));

        }

        private bool PedidoExists(int id)
        {
          return (_context.Pedido?.Any(e => e.Id == id)).GetValueOrDefault();
        }

        private async Task<int?> NroPedido()
        {
            var pedido = await _context.Pedido.OrderByDescending(p => p.NroPedido).FirstOrDefaultAsync();

            if (pedido == null)
            {
                return 30000;
            }
            return pedido.NroPedido + 5;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SushiPopG4.Models;

namespace SushiPopG4.Controllers
{
    public class CarritosItemsController : Controller
    {
        private readonly DbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public CarritosItemsController(DbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: CarritosItems
        
        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            var dbContext = _context.CarritoItem.Include(c => c.Carrito)
                                                .Include(c => c.Producto)
                                                .Where(c => c.Carrito.Cliente.Email.ToUpper() == user.NormalizedEmail)
                                                .ToListAsync();



            return View(await dbContext);
        }

        // GET: CarritosItems/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.CarritoItem == null)
            {
                return NotFound();
            }

            var carritoItem = await _context.CarritoItem
                .Include(c => c.Carrito)
                .Include(c => c.Producto)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (carritoItem == null)
            {
                return NotFound();
            }

            return View(carritoItem);
        }

        // GET: CarritosItems/Create
        [Authorize(Roles = "CLIENTE")]
        [HttpGet("Carrito/Create/{productoId?}")]
        public async Task<IActionResult> Create(int? productoId)
        {
            if (productoId == null) { }

            var producto = await _context.Producto.FindAsync(productoId);

            if(producto == null) { }

            var user = await _userManager.GetUserAsync(User);

            if (user == null) { }

            //Si usuario no es nulo
            var cliente = await _context.Cliente.Where(x => x.Email.ToUpper() == user.NormalizedEmail).FirstOrDefaultAsync();

            var carritoCliente = await _context.Carrito
                                    .Include(Carrito => Carrito.Cliente)
                                    .Include(Carrito => Carrito.CarritosItems)
                                    .Where(Carrito =>
                                    Carrito.Cliente.Email.ToUpper() == user.NormalizedEmail 
                                    &&
                                    Carrito.Cancelado == false 
                                    && 
                                    Carrito.Procesado == false)
                                    .FirstOrDefaultAsync();

            if (carritoCliente == null)
            {
                //Carrito nulo, entonces lo creo
                Carrito carritoNuevo = new Carrito();
                carritoNuevo.Procesado = false;
                carritoNuevo.Cancelado = false;
                carritoNuevo.ClienteId = cliente.Id;
                _context.Add(carritoNuevo);
                await _context.SaveChangesAsync();

                carritoCliente = await _context.Carrito
                    .Include(x=>x.Cliente)
                    .Include(x=>x.CarritosItems)
                    .OrderByDescending(x => x.Id)
                    .FirstOrDefaultAsync();
            }

            var precioProducto = producto.Precio;

            //sacar dia
            int dia = 1;
            var descuento = await _context.Descuento
                .Where(descuento => descuento.ProductoId == producto.Id 
                && 
                descuento.Activo == true
                &&
                descuento.Dia == dia)
                .FirstOrDefaultAsync();

            if(descuento != null)
            {
                precioProducto = precioProducto * (1 - descuento.Porcentaje / 100);
            }

            var itemBuscado = await _context.CarritoItem
                .Where(CarritoItem => CarritoItem.CarritoId == carritoCliente.Id
                &&
                CarritoItem.ProductoId == producto.Id)
                .FirstOrDefaultAsync();

            if (itemBuscado == null)
            {
                CarritoItem carritoItem = new CarritoItem();
                carritoItem.PrecioUnitarioConDescuento = precioProducto;
                carritoItem.Cantidad = 0;
                carritoItem.CarritoId = carritoCliente.Id;
                carritoItem.Producto = producto;
                carritoItem.ProductoId = producto.Id;

                itemBuscado = carritoItem;

                if(itemBuscado.Producto.Stock > 0) { 
                    _context.Add(carritoItem);
                    await _context.SaveChangesAsync();
                }
            }

                int stockProducto = producto.Stock;
                int cantidadItemsCarrito = itemBuscado.Cantidad;

                if(stockProducto < cantidadItemsCarrito)
                {
                    //Mensaje de que no hay stock
                }

                if(stockProducto > 0) { 

                itemBuscado.Cantidad += 1;
                producto.Stock -= 1;

                _context.Update(itemBuscado);
                await _context.SaveChangesAsync();
            }

            //ir a la grilla de items
            return RedirectToAction("", "Productos");
        }

        // POST: CarritosItems/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "EMPLEADO, ADMIN")]
        public async Task<IActionResult> Create([Bind("Id,PrecioUnitarioConDescuento,Cantidad,CarritoId,ProductoId")] CarritoItem carritoItem)
        {
            if (ModelState.IsValid)
            {
                _context.Add(carritoItem);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CarritoId"] = new SelectList(_context.Carrito, "Id", "Id", carritoItem.CarritoId);
            ViewData["ProductoId"] = new SelectList(_context.Set<Producto>(), "Id", "Descripcion", carritoItem.ProductoId);
            return View(carritoItem);
        }

        // GET: CarritosItems/Edit/5
        [Authorize(Roles = "EMPLEADO, ADMIN")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.CarritoItem == null)
            {
                return NotFound();
            }

            var carritoItem = await _context.CarritoItem.FindAsync(id);
            if (carritoItem == null)
            {
                return NotFound();
            }
            ViewData["CarritoId"] = new SelectList(_context.Carrito, "Id", "Id", carritoItem.CarritoId);
            ViewData["ProductoId"] = new SelectList(_context.Set<Producto>(), "Id", "Descripcion", carritoItem.ProductoId);
            return View(carritoItem);
        }

        // POST: CarritosItems/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "EMPLEADO, ADMIN")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,PrecioUnitarioConDescuento,Cantidad,CarritoId,ProductoId")] CarritoItem carritoItem)
        {
            if (id != carritoItem.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carritoItem);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarritoItemExists(carritoItem.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CarritoId"] = new SelectList(_context.Carrito, "Id", "Id", carritoItem.CarritoId);
            ViewData["ProductoId"] = new SelectList(_context.Set<Producto>(), "Id", "Descripcion", carritoItem.ProductoId);
            return View(carritoItem);
        }

        // GET: CarritosItems/Delete/5
        [Authorize(Roles = "CLIENTE")]
        [HttpGet("CarritosItems/Delete/{carritoItemId}")]
        public async Task<IActionResult> Delete(int? carritoItemId)
        {
            if (carritoItemId == null)
            {
                return NotFound();
            }

            var carritoItem = await _context.CarritoItem
                .Include(c => c.Carrito)
                .Include(c => c.Producto)
                .FirstOrDefaultAsync(m => m.Id == carritoItemId);
            if (carritoItem == null)
            {
                return NotFound();
            }

            var cantidad = carritoItem.Cantidad;
            var producto = carritoItem.Producto;

            producto.Stock += cantidad;

            _context.Remove(carritoItem);
            await _context.SaveChangesAsync();

            return RedirectToAction("", "Carritos");
        }

        // POST: CarritosItems/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "EMPLEADO, ADMIN")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.CarritoItem == null)
            {
                return Problem("Entity set 'DbContext.CarritoItem'  is null.");
            }
            var carritoItem = await _context.CarritoItem.FindAsync(id);
            if (carritoItem != null)
            {
                _context.CarritoItem.Remove(carritoItem);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CarritoItemExists(int id)
        {
          return (_context.CarritoItem?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

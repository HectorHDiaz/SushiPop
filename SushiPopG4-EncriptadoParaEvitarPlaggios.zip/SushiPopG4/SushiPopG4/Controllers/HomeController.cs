﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using SushiPopG4.Models;
using System.Diagnostics;
using System.Drawing.Printing;
using System.Globalization;

namespace SushiPopG4.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly DbContext _context;



        public HomeController(ILogger<HomeController> logger, DbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            string diaDeLaSemana = GetDayOfTheWeek();
            Descuento? descuento = await _context.Descuento.Include(d => d.Producto).FirstOrDefaultAsync(d => GetNameOfTheDay(d.Dia).Equals(diaDeLaSemana));

            DescuentoDiaViewModel descuentoDiaViewModel = new()
            {
                Dia = diaDeLaSemana,
                HorarioAtencion = GetHorarioAtencion(diaDeLaSemana)
            };

            if (descuento != null)
            {
                descuentoDiaViewModel.Descuento =  descuento.Porcentaje;
                descuentoDiaViewModel.Producto =  descuento.Producto.Nombre;
                descuentoDiaViewModel.ProductoId = descuento.ProductoId;
            }

          
            return View(descuentoDiaViewModel);
        }

        public IActionResult Legales()
        {
            return View();
        }

        public String GetDayOfTheWeek()
        {
            DateTime diaActual = DateTime.Today;

            return diaActual.ToString("dddd", new CultureInfo("es-ES")); 
        }

        public String GetNameOfTheDay(int day)
        {
            string nombreDelDia = string.Empty;
            switch (day)
            {
                case 1:
                    nombreDelDia = "lunes";
                    break;
                case 2:
                    nombreDelDia = "martes";
                    break;
                case 3:
                    nombreDelDia = "miércoles";
                    break;
                case 4:
                    nombreDelDia = "jueves";
                    break;
                case 5:
                    nombreDelDia = "viernes";
                    break;
                case 6:
                    nombreDelDia = "sábado";
                    break;
                case 7:
                    nombreDelDia = "domingo";
                    break;
            }
            return nombreDelDia;
        }

        public String GetHorarioAtencion(String dia)
        {
            String msg = string.Empty;

            if ( dia == "viernes" || dia == "sábado" || dia == "domingo")
            {
                msg ="11 a 14 horas y ";
            }

            return msg;
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}